﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1stpage
{
    public partial class Management : Form
    {
        public Management()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void team1comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void team2comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void goaltextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Enterbutton_Click(object sender, EventArgs e)
        {

        }

        private void teamsch1comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void teamsch2comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void EditScheduleEnterbutton_Click(object sender, EventArgs e)
        {

        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a1 = new Admin();
            a1.ShowDialog();
        }

        private void backbutton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a2 = new Admin();
            a2.ShowDialog();
        }


    }
}
