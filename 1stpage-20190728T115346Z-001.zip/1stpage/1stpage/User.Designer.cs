﻿namespace _1stpage
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User));
            this.UsertabControl = new System.Windows.Forms.TabControl();
            this.checkmatchscheduletab = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.Searchteamschedule = new System.Windows.Forms.TextBox();
            this.dataGridViewsch = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.checkmatchresulttab = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.matchresultsearch = new System.Windows.Forms.TextBox();
            this.dataGridViewres = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.buytickettab = new System.Windows.Forms.TabPage();
            this.printbutton = new System.Windows.Forms.Button();
            this.calculatebutton = new System.Windows.Forms.Button();
            this.amounttextBox = new System.Windows.Forms.TextBox();
            this.totallabel = new System.Windows.Forms.Label();
            this.normalradioButton = new System.Windows.Forms.RadioButton();
            this.vipradioButton = new System.Windows.Forms.RadioButton();
            this.datelabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.seattextBox = new System.Windows.Forms.TextBox();
            this.seatslabel = new System.Windows.Forms.Label();
            this.nametextBox = new System.Windows.Forms.TextBox();
            this.namelabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.helptab = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.UsertabControl.SuspendLayout();
            this.checkmatchscheduletab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.checkmatchresulttab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.buytickettab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.helptab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // UsertabControl
            // 
            this.UsertabControl.Controls.Add(this.checkmatchscheduletab);
            this.UsertabControl.Controls.Add(this.checkmatchresulttab);
            this.UsertabControl.Controls.Add(this.buytickettab);
            this.UsertabControl.Controls.Add(this.helptab);
            this.UsertabControl.Location = new System.Drawing.Point(2, 3);
            this.UsertabControl.Name = "UsertabControl";
            this.UsertabControl.SelectedIndex = 0;
            this.UsertabControl.Size = new System.Drawing.Size(662, 518);
            this.UsertabControl.TabIndex = 0;
            // 
            // checkmatchscheduletab
            // 
            this.checkmatchscheduletab.Controls.Add(this.label1);
            this.checkmatchscheduletab.Controls.Add(this.Searchteamschedule);
            this.checkmatchscheduletab.Controls.Add(this.dataGridViewsch);
            this.checkmatchscheduletab.Controls.Add(this.pictureBox3);
            this.checkmatchscheduletab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmatchscheduletab.Location = new System.Drawing.Point(4, 22);
            this.checkmatchscheduletab.Name = "checkmatchscheduletab";
            this.checkmatchscheduletab.Padding = new System.Windows.Forms.Padding(3);
            this.checkmatchscheduletab.Size = new System.Drawing.Size(654, 492);
            this.checkmatchscheduletab.TabIndex = 0;
            this.checkmatchscheduletab.Text = "CHECK MATCH SCHEDULE";
            this.checkmatchscheduletab.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightSlateGray;
            this.label1.Location = new System.Drawing.Point(32, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "SEARCH TEAM";
            // 
            // Searchteamschedule
            // 
            this.Searchteamschedule.Location = new System.Drawing.Point(32, 60);
            this.Searchteamschedule.Name = "Searchteamschedule";
            this.Searchteamschedule.Size = new System.Drawing.Size(175, 21);
            this.Searchteamschedule.TabIndex = 2;
            this.Searchteamschedule.TextChanged += new System.EventHandler(this.Searchteamschedule_TextChanged);
            // 
            // dataGridViewsch
            // 
            this.dataGridViewsch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewsch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridViewsch.Location = new System.Drawing.Point(32, 166);
            this.dataGridViewsch.Name = "dataGridViewsch";
            this.dataGridViewsch.Size = new System.Drawing.Size(590, 309);
            this.dataGridViewsch.TabIndex = 1;
            this.dataGridViewsch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewsch_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "TEAM1";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "TEAM2";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "DATE";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "TIME";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(-2, 1);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(656, 492);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // checkmatchresulttab
            // 
            this.checkmatchresulttab.Controls.Add(this.label2);
            this.checkmatchresulttab.Controls.Add(this.matchresultsearch);
            this.checkmatchresulttab.Controls.Add(this.dataGridViewres);
            this.checkmatchresulttab.Controls.Add(this.pictureBox4);
            this.checkmatchresulttab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmatchresulttab.Location = new System.Drawing.Point(4, 22);
            this.checkmatchresulttab.Name = "checkmatchresulttab";
            this.checkmatchresulttab.Padding = new System.Windows.Forms.Padding(3);
            this.checkmatchresulttab.Size = new System.Drawing.Size(654, 492);
            this.checkmatchresulttab.TabIndex = 1;
            this.checkmatchresulttab.Text = "CHECK MATCH RESULT";
            this.checkmatchresulttab.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightSlateGray;
            this.label2.Location = new System.Drawing.Point(30, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "SEARCH TEAMS";
            // 
            // matchresultsearch
            // 
            this.matchresultsearch.Location = new System.Drawing.Point(30, 103);
            this.matchresultsearch.Name = "matchresultsearch";
            this.matchresultsearch.Size = new System.Drawing.Size(167, 21);
            this.matchresultsearch.TabIndex = 3;
            this.matchresultsearch.TextChanged += new System.EventHandler(this.matchresultsearch_TextChanged);
            // 
            // dataGridViewres
            // 
            this.dataGridViewres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewres.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9});
            this.dataGridViewres.Location = new System.Drawing.Point(30, 165);
            this.dataGridViewres.Name = "dataGridViewres";
            this.dataGridViewres.Size = new System.Drawing.Size(589, 311);
            this.dataGridViewres.TabIndex = 2;
            this.dataGridViewres.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewres_CellContentClick);
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "TEAM1";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "GOALS";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.HeaderText = "TEAM2";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "GOALS";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "DATE";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(656, 492);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // buytickettab
            // 
            this.buytickettab.Controls.Add(this.printbutton);
            this.buytickettab.Controls.Add(this.calculatebutton);
            this.buytickettab.Controls.Add(this.amounttextBox);
            this.buytickettab.Controls.Add(this.totallabel);
            this.buytickettab.Controls.Add(this.normalradioButton);
            this.buytickettab.Controls.Add(this.vipradioButton);
            this.buytickettab.Controls.Add(this.datelabel);
            this.buytickettab.Controls.Add(this.dateTimePicker1);
            this.buytickettab.Controls.Add(this.seattextBox);
            this.buytickettab.Controls.Add(this.seatslabel);
            this.buytickettab.Controls.Add(this.nametextBox);
            this.buytickettab.Controls.Add(this.namelabel);
            this.buytickettab.Controls.Add(this.pictureBox2);
            this.buytickettab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buytickettab.Location = new System.Drawing.Point(4, 22);
            this.buytickettab.Name = "buytickettab";
            this.buytickettab.Padding = new System.Windows.Forms.Padding(3);
            this.buytickettab.Size = new System.Drawing.Size(654, 492);
            this.buytickettab.TabIndex = 2;
            this.buytickettab.Text = "BUY TICKET";
            this.buytickettab.UseVisualStyleBackColor = true;
            // 
            // printbutton
            // 
            this.printbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.printbutton.Location = new System.Drawing.Point(354, 323);
            this.printbutton.Name = "printbutton";
            this.printbutton.Size = new System.Drawing.Size(150, 32);
            this.printbutton.TabIndex = 13;
            this.printbutton.Text = "PRINT";
            this.printbutton.UseVisualStyleBackColor = false;
            this.printbutton.Click += new System.EventHandler(this.printbutton_Click);
            // 
            // calculatebutton
            // 
            this.calculatebutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.calculatebutton.Location = new System.Drawing.Point(95, 323);
            this.calculatebutton.Name = "calculatebutton";
            this.calculatebutton.Size = new System.Drawing.Size(101, 32);
            this.calculatebutton.TabIndex = 12;
            this.calculatebutton.Text = "CALCULATE";
            this.calculatebutton.UseVisualStyleBackColor = false;
            this.calculatebutton.Click += new System.EventHandler(this.calculatebutton_Click);
            // 
            // amounttextBox
            // 
            this.amounttextBox.Location = new System.Drawing.Point(206, 239);
            this.amounttextBox.Name = "amounttextBox";
            this.amounttextBox.Size = new System.Drawing.Size(100, 21);
            this.amounttextBox.TabIndex = 11;
            this.amounttextBox.TextChanged += new System.EventHandler(this.amounttextBox_TextChanged);
            // 
            // totallabel
            // 
            this.totallabel.AutoSize = true;
            this.totallabel.BackColor = System.Drawing.Color.LightSlateGray;
            this.totallabel.Location = new System.Drawing.Point(59, 239);
            this.totallabel.Name = "totallabel";
            this.totallabel.Size = new System.Drawing.Size(111, 15);
            this.totallabel.TabIndex = 10;
            this.totallabel.Text = "TOTAL AMOUNT";
            // 
            // normalradioButton
            // 
            this.normalradioButton.AutoSize = true;
            this.normalradioButton.BackColor = System.Drawing.Color.LightSlateGray;
            this.normalradioButton.Location = new System.Drawing.Point(409, 234);
            this.normalradioButton.Name = "normalradioButton";
            this.normalradioButton.Size = new System.Drawing.Size(187, 19);
            this.normalradioButton.TabIndex = 9;
            this.normalradioButton.TabStop = true;
            this.normalradioButton.Text = "NORMAL SEATS TK 2000";
            this.normalradioButton.UseVisualStyleBackColor = false;
            this.normalradioButton.CheckedChanged += new System.EventHandler(this.normalradioButton_CheckedChanged);
            // 
            // vipradioButton
            // 
            this.vipradioButton.AutoSize = true;
            this.vipradioButton.BackColor = System.Drawing.Color.LightSlateGray;
            this.vipradioButton.Location = new System.Drawing.Point(409, 182);
            this.vipradioButton.Name = "vipradioButton";
            this.vipradioButton.Size = new System.Drawing.Size(150, 19);
            this.vipradioButton.TabIndex = 8;
            this.vipradioButton.TabStop = true;
            this.vipradioButton.Text = "VIP SEATS TK 5000";
            this.vipradioButton.UseVisualStyleBackColor = false;
            this.vipradioButton.CheckedChanged += new System.EventHandler(this.vipradioButton_CheckedChanged);
            // 
            // datelabel
            // 
            this.datelabel.AutoSize = true;
            this.datelabel.BackColor = System.Drawing.Color.LightSlateGray;
            this.datelabel.Location = new System.Drawing.Point(56, 122);
            this.datelabel.Name = "datelabel";
            this.datelabel.Size = new System.Drawing.Size(42, 15);
            this.datelabel.TabIndex = 7;
            this.datelabel.Text = "DATE";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(206, 122);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 21);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // seattextBox
            // 
            this.seattextBox.Location = new System.Drawing.Point(206, 180);
            this.seattextBox.Name = "seattextBox";
            this.seattextBox.Size = new System.Drawing.Size(100, 21);
            this.seattextBox.TabIndex = 5;
            this.seattextBox.TextChanged += new System.EventHandler(this.seattextBox_TextChanged);
            // 
            // seatslabel
            // 
            this.seatslabel.AutoSize = true;
            this.seatslabel.BackColor = System.Drawing.Color.LightSlateGray;
            this.seatslabel.Location = new System.Drawing.Point(56, 180);
            this.seatslabel.Name = "seatslabel";
            this.seatslabel.Size = new System.Drawing.Size(50, 15);
            this.seatslabel.TabIndex = 3;
            this.seatslabel.Text = "SEATS";
            // 
            // nametextBox
            // 
            this.nametextBox.Location = new System.Drawing.Point(206, 65);
            this.nametextBox.Name = "nametextBox";
            this.nametextBox.Size = new System.Drawing.Size(100, 21);
            this.nametextBox.TabIndex = 2;
            this.nametextBox.TextChanged += new System.EventHandler(this.nametextBox_TextChanged);
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.BackColor = System.Drawing.Color.LightSlateGray;
            this.namelabel.Location = new System.Drawing.Point(56, 65);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(46, 15);
            this.namelabel.TabIndex = 1;
            this.namelabel.Text = "NAME";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-2, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(656, 492);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // helptab
            // 
            this.helptab.Controls.Add(this.pictureBox1);
            this.helptab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helptab.Location = new System.Drawing.Point(4, 22);
            this.helptab.Name = "helptab";
            this.helptab.Padding = new System.Windows.Forms.Padding(3);
            this.helptab.Size = new System.Drawing.Size(654, 492);
            this.helptab.TabIndex = 3;
            this.helptab.Text = "HELP";
            this.helptab.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(656, 492);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 523);
            this.Controls.Add(this.UsertabControl);
            this.Name = "User";
            this.Text = "User";
            this.UsertabControl.ResumeLayout(false);
            this.checkmatchscheduletab.ResumeLayout(false);
            this.checkmatchscheduletab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.checkmatchresulttab.ResumeLayout(false);
            this.checkmatchresulttab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.buytickettab.ResumeLayout(false);
            this.buytickettab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.helptab.ResumeLayout(false);
            this.helptab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl UsertabControl;
        private System.Windows.Forms.TabPage checkmatchscheduletab;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage checkmatchresulttab;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TabPage buytickettab;
        private System.Windows.Forms.Button printbutton;
        private System.Windows.Forms.Button calculatebutton;
        private System.Windows.Forms.TextBox amounttextBox;
        private System.Windows.Forms.Label totallabel;
        private System.Windows.Forms.RadioButton normalradioButton;
        private System.Windows.Forms.RadioButton vipradioButton;
        private System.Windows.Forms.Label datelabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox seattextBox;
        private System.Windows.Forms.Label seatslabel;
        private System.Windows.Forms.TextBox nametextBox;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage helptab;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Searchteamschedule;
        private System.Windows.Forms.DataGridView dataGridViewsch;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox matchresultsearch;
        private System.Windows.Forms.DataGridView dataGridViewres;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
    }
}