﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1stpage
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void nametextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void seattextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void amounttextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void vipradioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void normalradioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void calculatebutton_Click(object sender, EventArgs e)
        {

        }

        private void printbutton_Click(object sender, EventArgs e)
        {

        }

        private void Searchteamschedule_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewsch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void matchresultsearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewres_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
