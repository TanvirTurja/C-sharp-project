﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1stpage
{
    public partial class signlog : Form
    {
        public signlog()
        {
            InitializeComponent();
        }

        private void firstnamelabel_Click(object sender, EventArgs e)
        {

        }

       

        private void idlabelsign_Click(object sender, EventArgs e)
        {

        }

        private void passowrdlabelSIGN_Click(object sender, EventArgs e)
        {

        }

        private void FIRSTNAMEBoxSIGN_TextChanged(object sender, EventArgs e)
        {

        }


        private void IDBoxSIGN_TextChanged(object sender, EventArgs e)
        {

        }

        private void PASSWORDBoxSIGN_TextChanged(object sender, EventArgs e)
        {
           /* PASSWORDBoxSIGN.Text = "";
            PASSWORDBoxSIGN.PasswordChar = '*';
            PASSWORDBoxSIGN.MaxLength = 14;*/
        }

        private void SIGNUP_Click(object sender, EventArgs e)
        {
            DialogResult SIGNUP;
            SIGNUP = MessageBox.Show("Wait for Admin Approval");
        }

        private void IDLabelLOG_Click(object sender, EventArgs e)
        {

        }

        private void IDBoxLOG_TextChanged(object sender, EventArgs e)
        {

        }

        private void PASSWORDlabelLOG_Click(object sender, EventArgs e)
        {

        }

        private void PasswordBoxLOG_TextChanged(object sender, EventArgs e)
        {
           /* PasswordBoxLOG.Text = "";
            PasswordBoxLOG.PasswordChar = '*';
            PasswordBoxLOG.MaxLength = 14;*/
        }

        private void loginbutton_Click(object sender, EventArgs e)
        {
          
            if (AdminButton.Checked)
            {
                this.Hide();
                Admin f1 = new Admin();
                f1.ShowDialog();
            }

            else if (UserButton.Checked)
            {
                this.Hide();
                User u1 = new User();
                u1.ShowDialog();
            }

        }

        private void IDlinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void signuptab_Click(object sender, EventArgs e)
        {

        }

        private void UserButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void AdminButton_CheckedChanged(object sender, EventArgs e)
        {
            
        }

       

        private void UserButtonsign_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Usersignuplabel_Click(object sender, EventArgs e)
        {

        }
    }
}
