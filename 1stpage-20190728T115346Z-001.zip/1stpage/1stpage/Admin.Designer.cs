﻿namespace _1stpage
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Managementbutton = new System.Windows.Forms.Button();
            this.Settingsbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(656, 492);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Managementbutton
            // 
            this.Managementbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.Managementbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Managementbutton.Location = new System.Drawing.Point(131, 379);
            this.Managementbutton.Name = "Managementbutton";
            this.Managementbutton.Size = new System.Drawing.Size(116, 23);
            this.Managementbutton.TabIndex = 1;
            this.Managementbutton.Text = "MANAGEMENT";
            this.Managementbutton.UseVisualStyleBackColor = false;
            this.Managementbutton.Click += new System.EventHandler(this.Managementbutton_Click);
            // 
            // Settingsbutton
            // 
            this.Settingsbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.Settingsbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Settingsbutton.Location = new System.Drawing.Point(411, 379);
            this.Settingsbutton.Name = "Settingsbutton";
            this.Settingsbutton.Size = new System.Drawing.Size(116, 23);
            this.Settingsbutton.TabIndex = 2;
            this.Settingsbutton.Text = "SETTINGS";
            this.Settingsbutton.UseVisualStyleBackColor = false;
            this.Settingsbutton.Click += new System.EventHandler(this.Settingsbutton_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 493);
            this.Controls.Add(this.Settingsbutton);
            this.Controls.Add(this.Managementbutton);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Admin";
            this.Text = "Admin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Managementbutton;
        private System.Windows.Forms.Button Settingsbutton;

    }
}