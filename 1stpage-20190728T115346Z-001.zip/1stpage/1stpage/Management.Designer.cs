﻿namespace _1stpage
{
    partial class Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Management));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Matchresulttab = new System.Windows.Forms.TabPage();
            this.Enterbutton = new System.Windows.Forms.Button();
            this.Datelabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.goaltextBox = new System.Windows.Forms.TextBox();
            this.goalslabel = new System.Windows.Forms.Label();
            this.team2comboBox = new System.Windows.Forms.ComboBox();
            this.team1comboBox = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Editmatchscheduletab = new System.Windows.Forms.TabPage();
            this.EditScheduleEnterbutton = new System.Windows.Forms.Button();
            this.DateTimelabel = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.teamsch2comboBox = new System.Windows.Forms.ComboBox();
            this.teamsch1comboBox = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.backbutton1 = new System.Windows.Forms.Button();
            this.backbutton2 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.Matchresulttab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Editmatchscheduletab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Matchresulttab);
            this.tabControl1.Controls.Add(this.Editmatchscheduletab);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(659, 520);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // Matchresulttab
            // 
            this.Matchresulttab.BackColor = System.Drawing.Color.LightSlateGray;
            this.Matchresulttab.Controls.Add(this.backbutton1);
            this.Matchresulttab.Controls.Add(this.Enterbutton);
            this.Matchresulttab.Controls.Add(this.Datelabel);
            this.Matchresulttab.Controls.Add(this.dateTimePicker1);
            this.Matchresulttab.Controls.Add(this.goaltextBox);
            this.Matchresulttab.Controls.Add(this.goalslabel);
            this.Matchresulttab.Controls.Add(this.team2comboBox);
            this.Matchresulttab.Controls.Add(this.team1comboBox);
            this.Matchresulttab.Controls.Add(this.pictureBox1);
            this.Matchresulttab.Location = new System.Drawing.Point(4, 22);
            this.Matchresulttab.Name = "Matchresulttab";
            this.Matchresulttab.Padding = new System.Windows.Forms.Padding(3);
            this.Matchresulttab.Size = new System.Drawing.Size(651, 494);
            this.Matchresulttab.TabIndex = 0;
            this.Matchresulttab.Text = "MATCH RESULT";
            // 
            // Enterbutton
            // 
            this.Enterbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.Enterbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enterbutton.Location = new System.Drawing.Point(331, 388);
            this.Enterbutton.Name = "Enterbutton";
            this.Enterbutton.Size = new System.Drawing.Size(75, 23);
            this.Enterbutton.TabIndex = 9;
            this.Enterbutton.Text = "ENTER";
            this.Enterbutton.UseVisualStyleBackColor = false;
            this.Enterbutton.Click += new System.EventHandler(this.Enterbutton_Click);
            // 
            // Datelabel
            // 
            this.Datelabel.AutoSize = true;
            this.Datelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datelabel.Location = new System.Drawing.Point(118, 295);
            this.Datelabel.Name = "Datelabel";
            this.Datelabel.Size = new System.Drawing.Size(42, 15);
            this.Datelabel.TabIndex = 8;
            this.Datelabel.Text = "DATE";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(206, 295);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 7;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // goaltextBox
            // 
            this.goaltextBox.Location = new System.Drawing.Point(206, 230);
            this.goaltextBox.Name = "goaltextBox";
            this.goaltextBox.Size = new System.Drawing.Size(100, 20);
            this.goaltextBox.TabIndex = 4;
            this.goaltextBox.TextChanged += new System.EventHandler(this.goaltextBox_TextChanged);
            // 
            // goalslabel
            // 
            this.goalslabel.AutoSize = true;
            this.goalslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goalslabel.Location = new System.Drawing.Point(118, 230);
            this.goalslabel.Name = "goalslabel";
            this.goalslabel.Size = new System.Drawing.Size(52, 15);
            this.goalslabel.TabIndex = 3;
            this.goalslabel.Text = "GOALS";
            // 
            // team2comboBox
            // 
            this.team2comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.team2comboBox.FormattingEnabled = true;
            this.team2comboBox.Items.AddRange(new object[] {
            "Basel",
            "Benfica",
            "CSKA Moskva",
            "Manchester United",
            "",
            "",
            "Anderlecht",
            "Bayern München ",
            "Celtic",
            "Paris Saint-Germain",
            "",
            "",
            "Atlético Madrid",
            "Chelsea",
            "Qarabağ",
            "Roma",
            "",
            "Barcelona",
            "Juventus",
            "Olympiacos",
            "Sporting CP",
            "",
            "",
            "Liverpool",
            "Maribor",
            "Sevilla",
            "Spartak Moskva",
            "",
            "",
            "Feyenoord",
            "Manchester City",
            "Napoli",
            "Shakhtar Donetsk",
            "",
            "",
            "",
            "Beşiktaş",
            "Monaco",
            "Porto",
            "RB Leipzig",
            "",
            "",
            "APOEL",
            "Borussia Dortmund",
            "Real Madrid",
            "Tottenham Hotspur"});
            this.team2comboBox.Location = new System.Drawing.Point(121, 165);
            this.team2comboBox.Name = "team2comboBox";
            this.team2comboBox.Size = new System.Drawing.Size(121, 23);
            this.team2comboBox.TabIndex = 2;
            this.team2comboBox.Text = "TEAM 2";
            this.team2comboBox.SelectedIndexChanged += new System.EventHandler(this.team2comboBox_SelectedIndexChanged);
            // 
            // team1comboBox
            // 
            this.team1comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.team1comboBox.FormattingEnabled = true;
            this.team1comboBox.Items.AddRange(new object[] {
            "Basel",
            "Benfica",
            "CSKA Moskva",
            "Manchester United",
            "",
            "",
            "Anderlecht",
            "Bayern München ",
            "Celtic",
            "Paris Saint-Germain",
            "",
            "",
            "Atlético Madrid",
            "Chelsea",
            "Qarabağ",
            "Roma",
            "",
            "Barcelona",
            "Juventus",
            "Olympiacos",
            "Sporting CP",
            "",
            "",
            "Liverpool",
            "Maribor",
            "Sevilla",
            "Spartak Moskva",
            "",
            "",
            "Feyenoord",
            "Manchester City",
            "Napoli",
            "Shakhtar Donetsk",
            "",
            "",
            "",
            "Beşiktaş",
            "Monaco",
            "Porto",
            "RB Leipzig",
            "",
            "",
            "APOEL",
            "Borussia Dortmund",
            "Real Madrid",
            "Tottenham Hotspur"});
            this.team1comboBox.Location = new System.Drawing.Point(121, 112);
            this.team1comboBox.Name = "team1comboBox";
            this.team1comboBox.Size = new System.Drawing.Size(121, 23);
            this.team1comboBox.TabIndex = 1;
            this.team1comboBox.Text = "TEAM 1";
            this.team1comboBox.SelectedIndexChanged += new System.EventHandler(this.team1comboBox_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-9, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(656, 492);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Editmatchscheduletab
            // 
            this.Editmatchscheduletab.BackColor = System.Drawing.Color.LightSlateGray;
            this.Editmatchscheduletab.Controls.Add(this.backbutton2);
            this.Editmatchscheduletab.Controls.Add(this.EditScheduleEnterbutton);
            this.Editmatchscheduletab.Controls.Add(this.DateTimelabel);
            this.Editmatchscheduletab.Controls.Add(this.dateTimePicker2);
            this.Editmatchscheduletab.Controls.Add(this.teamsch2comboBox);
            this.Editmatchscheduletab.Controls.Add(this.teamsch1comboBox);
            this.Editmatchscheduletab.Controls.Add(this.pictureBox2);
            this.Editmatchscheduletab.Location = new System.Drawing.Point(4, 22);
            this.Editmatchscheduletab.Name = "Editmatchscheduletab";
            this.Editmatchscheduletab.Padding = new System.Windows.Forms.Padding(3);
            this.Editmatchscheduletab.Size = new System.Drawing.Size(651, 494);
            this.Editmatchscheduletab.TabIndex = 1;
            this.Editmatchscheduletab.Text = "EDIT MATCH SCHEDULE";
            // 
            // EditScheduleEnterbutton
            // 
            this.EditScheduleEnterbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.EditScheduleEnterbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditScheduleEnterbutton.Location = new System.Drawing.Point(364, 320);
            this.EditScheduleEnterbutton.Name = "EditScheduleEnterbutton";
            this.EditScheduleEnterbutton.Size = new System.Drawing.Size(75, 23);
            this.EditScheduleEnterbutton.TabIndex = 5;
            this.EditScheduleEnterbutton.Text = "ENTER";
            this.EditScheduleEnterbutton.UseVisualStyleBackColor = false;
            this.EditScheduleEnterbutton.Click += new System.EventHandler(this.EditScheduleEnterbutton_Click);
            // 
            // DateTimelabel
            // 
            this.DateTimelabel.AutoSize = true;
            this.DateTimelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimelabel.Location = new System.Drawing.Point(121, 213);
            this.DateTimelabel.Name = "DateTimelabel";
            this.DateTimelabel.Size = new System.Drawing.Size(83, 15);
            this.DateTimelabel.TabIndex = 4;
            this.DateTimelabel.Text = "DATE & TIME";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(239, 213);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 3;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // teamsch2comboBox
            // 
            this.teamsch2comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teamsch2comboBox.FormattingEnabled = true;
            this.teamsch2comboBox.Items.AddRange(new object[] {
            "Basel",
            "Benfica",
            "CSKA Moskva",
            "Manchester United",
            "",
            "",
            "Anderlecht",
            "Bayern München ",
            "Celtic",
            "Paris Saint-Germain",
            "",
            "",
            "Atlético Madrid",
            "Chelsea",
            "Qarabag",
            "Roma",
            "",
            "Barcelona",
            "Juventus",
            "Olympiacos",
            "Sporting CP",
            "",
            "",
            "Liverpool",
            "Maribor",
            "Sevilla",
            "Spartak Moskva",
            "",
            "",
            "Feyenoord",
            "Manchester City",
            "Napoli",
            "Shakhtar Donetsk",
            "",
            "",
            "",
            "Besiktas",
            "Monaco",
            "Porto",
            "RB Leipzig",
            "",
            "",
            "APOEL",
            "Borussia Dortmund",
            "Real Madrid",
            "Tottenham Hotspur"});
            this.teamsch2comboBox.Location = new System.Drawing.Point(124, 133);
            this.teamsch2comboBox.Name = "teamsch2comboBox";
            this.teamsch2comboBox.Size = new System.Drawing.Size(121, 23);
            this.teamsch2comboBox.TabIndex = 2;
            this.teamsch2comboBox.Text = "TEAM 2";
            this.teamsch2comboBox.SelectedIndexChanged += new System.EventHandler(this.teamsch2comboBox_SelectedIndexChanged);
            // 
            // teamsch1comboBox
            // 
            this.teamsch1comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teamsch1comboBox.FormattingEnabled = true;
            this.teamsch1comboBox.Items.AddRange(new object[] {
            "Basel",
            "Benfica",
            "CSKA Moskva",
            "Manchester United",
            "",
            "",
            "Anderlecht",
            "Bayern München ",
            "Celtic",
            "Paris Saint-Germain",
            "",
            "",
            "Atlético Madrid",
            "Chelsea",
            "Qarabag",
            "Roma",
            "",
            "Barcelona",
            "Juventus",
            "Olympiacos",
            "Sporting CP",
            "",
            "",
            "Liverpool",
            "Maribor",
            "Sevilla",
            "Spartak Moskva",
            "",
            "",
            "Feyenoord",
            "Manchester City",
            "Napoli",
            "Shakhtar Donetsk",
            "",
            "",
            "",
            "Besiktas",
            "Monaco",
            "Porto",
            "RB Leipzig",
            "",
            "",
            "APOEL",
            "Borussia Dortmund",
            "Real Madrid",
            "Tottenham Hotspur"});
            this.teamsch1comboBox.Location = new System.Drawing.Point(124, 75);
            this.teamsch1comboBox.Name = "teamsch1comboBox";
            this.teamsch1comboBox.Size = new System.Drawing.Size(121, 23);
            this.teamsch1comboBox.TabIndex = 1;
            this.teamsch1comboBox.Text = "TEAM 1";
            this.teamsch1comboBox.SelectedIndexChanged += new System.EventHandler(this.teamsch1comboBox_SelectedIndexChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-8, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(656, 492);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // backbutton1
            // 
            this.backbutton1.BackColor = System.Drawing.Color.LightSlateGray;
            this.backbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backbutton1.Location = new System.Drawing.Point(121, 388);
            this.backbutton1.Name = "backbutton1";
            this.backbutton1.Size = new System.Drawing.Size(75, 23);
            this.backbutton1.TabIndex = 10;
            this.backbutton1.Text = "BACK";
            this.backbutton1.UseVisualStyleBackColor = false;
            this.backbutton1.Click += new System.EventHandler(this.backbutton1_Click);
            // 
            // backbutton2
            // 
            this.backbutton2.BackColor = System.Drawing.Color.LightSlateGray;
            this.backbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backbutton2.Location = new System.Drawing.Point(124, 320);
            this.backbutton2.Name = "backbutton2";
            this.backbutton2.Size = new System.Drawing.Size(75, 23);
            this.backbutton2.TabIndex = 6;
            this.backbutton2.Text = "BACK";
            this.backbutton2.UseVisualStyleBackColor = false;
            this.backbutton2.Click += new System.EventHandler(this.backbutton2_Click);
            // 
            // Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 514);
            this.Controls.Add(this.tabControl1);
            this.Name = "Management";
            this.Text = "Management";
            this.tabControl1.ResumeLayout(false);
            this.Matchresulttab.ResumeLayout(false);
            this.Matchresulttab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Editmatchscheduletab.ResumeLayout(false);
            this.Editmatchscheduletab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Matchresulttab;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage Editmatchscheduletab;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ComboBox team2comboBox;
        private System.Windows.Forms.ComboBox team1comboBox;
        private System.Windows.Forms.Label Datelabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox goaltextBox;
        private System.Windows.Forms.Label goalslabel;
        private System.Windows.Forms.Button Enterbutton;
        private System.Windows.Forms.Button EditScheduleEnterbutton;
        private System.Windows.Forms.Label DateTimelabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.ComboBox teamsch2comboBox;
        private System.Windows.Forms.ComboBox teamsch1comboBox;
        private System.Windows.Forms.Button backbutton1;
        private System.Windows.Forms.Button backbutton2;
    }
}