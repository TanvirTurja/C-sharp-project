﻿namespace _1stpage
{
    partial class signlog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signlog));
            this.signlogin = new System.Windows.Forms.TabControl();
            this.LOGINTAB = new System.Windows.Forms.TabPage();
            this.UserButton = new System.Windows.Forms.RadioButton();
            this.AdminButton = new System.Windows.Forms.RadioButton();
            this.loginbutton = new System.Windows.Forms.Button();
            this.PasswordBoxLOG = new System.Windows.Forms.TextBox();
            this.IDBoxLOG = new System.Windows.Forms.TextBox();
            this.PASSWORDlabelLOG = new System.Windows.Forms.Label();
            this.IDLabelLOG = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.signuptab = new System.Windows.Forms.TabPage();
            this.SIGNUP = new System.Windows.Forms.Button();
            this.PASSWORDBoxSIGN = new System.Windows.Forms.TextBox();
            this.IDBoxSIGN = new System.Windows.Forms.TextBox();
            this.FIRSTNAMEBoxSIGN = new System.Windows.Forms.TextBox();
            this.passowrdlabelSIGN = new System.Windows.Forms.Label();
            this.idlabelsign = new System.Windows.Forms.Label();
            this.firstnamelabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Usersignuplabel = new System.Windows.Forms.Label();
            this.signlogin.SuspendLayout();
            this.LOGINTAB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.signuptab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // signlogin
            // 
            this.signlogin.Controls.Add(this.LOGINTAB);
            this.signlogin.Controls.Add(this.signuptab);
            this.signlogin.Location = new System.Drawing.Point(0, 2);
            this.signlogin.Name = "signlogin";
            this.signlogin.SelectedIndex = 0;
            this.signlogin.Size = new System.Drawing.Size(666, 524);
            this.signlogin.TabIndex = 0;
            // 
            // LOGINTAB
            // 
            this.LOGINTAB.BackColor = System.Drawing.Color.Silver;
            this.LOGINTAB.Controls.Add(this.UserButton);
            this.LOGINTAB.Controls.Add(this.AdminButton);
            this.LOGINTAB.Controls.Add(this.loginbutton);
            this.LOGINTAB.Controls.Add(this.PasswordBoxLOG);
            this.LOGINTAB.Controls.Add(this.IDBoxLOG);
            this.LOGINTAB.Controls.Add(this.PASSWORDlabelLOG);
            this.LOGINTAB.Controls.Add(this.IDLabelLOG);
            this.LOGINTAB.Controls.Add(this.pictureBox1);
            this.LOGINTAB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGINTAB.Location = new System.Drawing.Point(4, 22);
            this.LOGINTAB.Name = "LOGINTAB";
            this.LOGINTAB.Padding = new System.Windows.Forms.Padding(3);
            this.LOGINTAB.Size = new System.Drawing.Size(658, 498);
            this.LOGINTAB.TabIndex = 0;
            this.LOGINTAB.Text = "LOGIN";
            // 
            // UserButton
            // 
            this.UserButton.AutoSize = true;
            this.UserButton.BackColor = System.Drawing.Color.LightSlateGray;
            this.UserButton.Location = new System.Drawing.Point(176, 71);
            this.UserButton.Name = "UserButton";
            this.UserButton.Size = new System.Drawing.Size(68, 20);
            this.UserButton.TabIndex = 6;
            this.UserButton.TabStop = true;
            this.UserButton.Text = "USER";
            this.UserButton.UseVisualStyleBackColor = false;
            this.UserButton.CheckedChanged += new System.EventHandler(this.UserButton_CheckedChanged);
            // 
            // AdminButton
            // 
            this.AdminButton.AutoSize = true;
            this.AdminButton.BackColor = System.Drawing.Color.LightSlateGray;
            this.AdminButton.Location = new System.Drawing.Point(46, 71);
            this.AdminButton.Name = "AdminButton";
            this.AdminButton.Size = new System.Drawing.Size(74, 20);
            this.AdminButton.TabIndex = 5;
            this.AdminButton.TabStop = true;
            this.AdminButton.Text = "ADMIN";
            this.AdminButton.UseVisualStyleBackColor = false;
            this.AdminButton.CheckedChanged += new System.EventHandler(this.AdminButton_CheckedChanged);
            // 
            // loginbutton
            // 
            this.loginbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.loginbutton.Location = new System.Drawing.Point(201, 345);
            this.loginbutton.Name = "loginbutton";
            this.loginbutton.Size = new System.Drawing.Size(75, 27);
            this.loginbutton.TabIndex = 4;
            this.loginbutton.Text = "LOGIN";
            this.loginbutton.UseVisualStyleBackColor = false;
            this.loginbutton.Click += new System.EventHandler(this.loginbutton_Click);
            // 
            // PasswordBoxLOG
            // 
            this.PasswordBoxLOG.Location = new System.Drawing.Point(176, 279);
            this.PasswordBoxLOG.Name = "PasswordBoxLOG";
            this.PasswordBoxLOG.Size = new System.Drawing.Size(100, 22);
            this.PasswordBoxLOG.TabIndex = 3;
            this.PasswordBoxLOG.TextChanged += new System.EventHandler(this.PasswordBoxLOG_TextChanged);
            // 
            // IDBoxLOG
            // 
            this.IDBoxLOG.Location = new System.Drawing.Point(176, 172);
            this.IDBoxLOG.Name = "IDBoxLOG";
            this.IDBoxLOG.Size = new System.Drawing.Size(100, 22);
            this.IDBoxLOG.TabIndex = 2;
            this.IDBoxLOG.TextChanged += new System.EventHandler(this.IDBoxLOG_TextChanged);
            // 
            // PASSWORDlabelLOG
            // 
            this.PASSWORDlabelLOG.AutoSize = true;
            this.PASSWORDlabelLOG.BackColor = System.Drawing.Color.LightSlateGray;
            this.PASSWORDlabelLOG.Location = new System.Drawing.Point(43, 279);
            this.PASSWORDlabelLOG.Name = "PASSWORDlabelLOG";
            this.PASSWORDlabelLOG.Size = new System.Drawing.Size(95, 16);
            this.PASSWORDlabelLOG.TabIndex = 1;
            this.PASSWORDlabelLOG.Text = "PASSWORD";
            this.PASSWORDlabelLOG.Click += new System.EventHandler(this.PASSWORDlabelLOG_Click);
            // 
            // IDLabelLOG
            // 
            this.IDLabelLOG.AutoSize = true;
            this.IDLabelLOG.BackColor = System.Drawing.Color.LightSlateGray;
            this.IDLabelLOG.Location = new System.Drawing.Point(43, 178);
            this.IDLabelLOG.Name = "IDLabelLOG";
            this.IDLabelLOG.Size = new System.Drawing.Size(23, 16);
            this.IDLabelLOG.TabIndex = 0;
            this.IDLabelLOG.Text = "ID";
            this.IDLabelLOG.Click += new System.EventHandler(this.IDLabelLOG_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(656, 492);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // signuptab
            // 
            this.signuptab.BackColor = System.Drawing.Color.Silver;
            this.signuptab.Controls.Add(this.Usersignuplabel);
            this.signuptab.Controls.Add(this.SIGNUP);
            this.signuptab.Controls.Add(this.PASSWORDBoxSIGN);
            this.signuptab.Controls.Add(this.IDBoxSIGN);
            this.signuptab.Controls.Add(this.FIRSTNAMEBoxSIGN);
            this.signuptab.Controls.Add(this.passowrdlabelSIGN);
            this.signuptab.Controls.Add(this.idlabelsign);
            this.signuptab.Controls.Add(this.firstnamelabel);
            this.signuptab.Controls.Add(this.pictureBox2);
            this.signuptab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signuptab.Location = new System.Drawing.Point(4, 22);
            this.signuptab.Name = "signuptab";
            this.signuptab.Padding = new System.Windows.Forms.Padding(3);
            this.signuptab.Size = new System.Drawing.Size(658, 498);
            this.signuptab.TabIndex = 1;
            this.signuptab.Text = "SIGNUP";
            this.signuptab.Click += new System.EventHandler(this.signuptab_Click);
            // 
            // SIGNUP
            // 
            this.SIGNUP.BackColor = System.Drawing.Color.LightSlateGray;
            this.SIGNUP.Location = new System.Drawing.Point(193, 374);
            this.SIGNUP.Name = "SIGNUP";
            this.SIGNUP.Size = new System.Drawing.Size(87, 23);
            this.SIGNUP.TabIndex = 8;
            this.SIGNUP.Text = "SIGN UP";
            this.SIGNUP.UseVisualStyleBackColor = false;
            this.SIGNUP.Click += new System.EventHandler(this.SIGNUP_Click);
            // 
            // PASSWORDBoxSIGN
            // 
            this.PASSWORDBoxSIGN.Location = new System.Drawing.Point(181, 272);
            this.PASSWORDBoxSIGN.Name = "PASSWORDBoxSIGN";
            this.PASSWORDBoxSIGN.Size = new System.Drawing.Size(100, 22);
            this.PASSWORDBoxSIGN.TabIndex = 7;
            this.PASSWORDBoxSIGN.TextChanged += new System.EventHandler(this.PASSWORDBoxSIGN_TextChanged);
            // 
            // IDBoxSIGN
            // 
            this.IDBoxSIGN.Location = new System.Drawing.Point(181, 198);
            this.IDBoxSIGN.Name = "IDBoxSIGN";
            this.IDBoxSIGN.Size = new System.Drawing.Size(100, 22);
            this.IDBoxSIGN.TabIndex = 6;
            this.IDBoxSIGN.TextChanged += new System.EventHandler(this.IDBoxSIGN_TextChanged);
            // 
            // FIRSTNAMEBoxSIGN
            // 
            this.FIRSTNAMEBoxSIGN.Location = new System.Drawing.Point(181, 125);
            this.FIRSTNAMEBoxSIGN.Name = "FIRSTNAMEBoxSIGN";
            this.FIRSTNAMEBoxSIGN.Size = new System.Drawing.Size(100, 22);
            this.FIRSTNAMEBoxSIGN.TabIndex = 4;
            this.FIRSTNAMEBoxSIGN.TextChanged += new System.EventHandler(this.FIRSTNAMEBoxSIGN_TextChanged);
            // 
            // passowrdlabelSIGN
            // 
            this.passowrdlabelSIGN.AutoSize = true;
            this.passowrdlabelSIGN.BackColor = System.Drawing.Color.LightSlateGray;
            this.passowrdlabelSIGN.Location = new System.Drawing.Point(35, 272);
            this.passowrdlabelSIGN.Name = "passowrdlabelSIGN";
            this.passowrdlabelSIGN.Size = new System.Drawing.Size(95, 16);
            this.passowrdlabelSIGN.TabIndex = 3;
            this.passowrdlabelSIGN.Text = "PASSWORD";
            this.passowrdlabelSIGN.Click += new System.EventHandler(this.passowrdlabelSIGN_Click);
            // 
            // idlabelsign
            // 
            this.idlabelsign.AutoSize = true;
            this.idlabelsign.BackColor = System.Drawing.Color.LightSlateGray;
            this.idlabelsign.Location = new System.Drawing.Point(35, 198);
            this.idlabelsign.Name = "idlabelsign";
            this.idlabelsign.Size = new System.Drawing.Size(23, 16);
            this.idlabelsign.TabIndex = 2;
            this.idlabelsign.Text = "ID";
            this.idlabelsign.Click += new System.EventHandler(this.idlabelsign_Click);
            // 
            // firstnamelabel
            // 
            this.firstnamelabel.AutoSize = true;
            this.firstnamelabel.BackColor = System.Drawing.Color.LightSlateGray;
            this.firstnamelabel.Location = new System.Drawing.Point(35, 125);
            this.firstnamelabel.Name = "firstnamelabel";
            this.firstnamelabel.Size = new System.Drawing.Size(51, 16);
            this.firstnamelabel.TabIndex = 0;
            this.firstnamelabel.Text = "NAME";
            this.firstnamelabel.Click += new System.EventHandler(this.firstnamelabel_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(656, 492);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // Usersignuplabel
            // 
            this.Usersignuplabel.AutoSize = true;
            this.Usersignuplabel.BackColor = System.Drawing.Color.LightSlateGray;
            this.Usersignuplabel.Location = new System.Drawing.Point(35, 58);
            this.Usersignuplabel.Name = "Usersignuplabel";
            this.Usersignuplabel.Size = new System.Drawing.Size(115, 16);
            this.Usersignuplabel.TabIndex = 10;
            this.Usersignuplabel.Text = "USER SIGN UP";
            this.Usersignuplabel.Click += new System.EventHandler(this.Usersignuplabel_Click);
            // 
            // signlog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 521);
            this.Controls.Add(this.signlogin);
            this.Name = "signlog";
            this.Text = "signlog";
            this.signlogin.ResumeLayout(false);
            this.LOGINTAB.ResumeLayout(false);
            this.LOGINTAB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.signuptab.ResumeLayout(false);
            this.signuptab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl signlogin;
        private System.Windows.Forms.TabPage LOGINTAB;
        private System.Windows.Forms.Button loginbutton;
        private System.Windows.Forms.TextBox PasswordBoxLOG;
        private System.Windows.Forms.TextBox IDBoxLOG;
        private System.Windows.Forms.Label PASSWORDlabelLOG;
        private System.Windows.Forms.Label IDLabelLOG;
        private System.Windows.Forms.TabPage signuptab;
        private System.Windows.Forms.Button SIGNUP;
        private System.Windows.Forms.TextBox PASSWORDBoxSIGN;
        private System.Windows.Forms.TextBox IDBoxSIGN;
        private System.Windows.Forms.TextBox FIRSTNAMEBoxSIGN;
        private System.Windows.Forms.Label passowrdlabelSIGN;
        private System.Windows.Forms.Label idlabelsign;
        private System.Windows.Forms.Label firstnamelabel;
        private System.Windows.Forms.RadioButton UserButton;
        private System.Windows.Forms.RadioButton AdminButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Usersignuplabel;
    }
}